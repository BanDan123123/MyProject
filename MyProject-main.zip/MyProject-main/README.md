# MyProject

Simple Python project with CI/CD
